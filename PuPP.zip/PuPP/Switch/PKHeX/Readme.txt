To use PKHex and all the plugins you must put or copy the folder into Documents because its the place not neer system32 so it wont mess up your pc 

After that run the exe and wait untill its done then you have installed PKHeX!