i wont provide any roms bc u should dump them from ur switch lul
